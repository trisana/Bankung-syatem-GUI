
/**
 * Write a description of class BankCard here.
 *
 * @author (22067339 Trisana Gurung)
 * @version (1.0.0)
 */
public class BankCard
{
    //Declaring attribute such as clientName,issuerBank,bankAccount,card_id,balanceAmount.
    private String clientName;
    private String issuerBank;
    private String bankAccount;
    private int card_id;
    private int balanceAmount;
    public BankCard(String clientName, String issuerBank, String bankAccount, int card_id, int balanceAmount)
    {
        this.clientName = "";
        this.issuerBank = issuerBank;
        this.bankAccount = bankAccount;
        this.card_id = card_id;
        this.balanceAmount = balanceAmount;
    }
    //accessor methods to get cilentName,issuerBank,bankAcount,balanceAmount and card_id
    public String getclientName()
    {
        return this.clientName;
    }
    //setter method to set cilentName and balanceAmount
    public void setClientName(String clientName)
    {
        this.clientName = clientName;
    }
    public String getissuerBank()
    {
        return this.issuerBank;
    }
    public String getbankAccount()
    {
        return this.bankAccount;
    }
    public int getcard_id() 
    {
        return this.card_id;
    }
    public int getbalanceAmount()
    {
        return this.balanceAmount;
    }
    public void setBalanceAmount(int balanceAmount)
    {
        this.balanceAmount = balanceAmount;
    }
    //Display methods of those attributes.
    public void display()
    {
        //ClientName whether is empty or not.
        if(clientName.isEmpty())
        {
            System.out.println("The unknown Client name !!");
        }
        else 
        {
            System.out.println("client name is:"+this.getclientName());
            System.out.println("issuerBank is:"+this.getissuerBank());
            System.out.println("BankAccount is:"+this.getbankAccount());
            System.out.println("Card_id is:"+this.getcard_id());
            System.out.println("BalanceAmount is:"+this.getbalanceAmount());
        }
    }
}
