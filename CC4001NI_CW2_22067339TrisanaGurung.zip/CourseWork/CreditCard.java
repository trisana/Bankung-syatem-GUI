
/**
 * Write a description of class Credit_Card here.
 *
 * @author (22067339 Trisana Gurung)
 * @version (1.0.0)
 */
public class CreditCard extends BankCard
{
    //Declaring attribute such as cvc_Number,credit_Limit,interestRate,expirationDate,gracePeriod,isGranted
    private int cvc_Number;
    private double credit_Limit;
    private double interestRate;
    private String expirationDate;
    private int gracePeriod;
    private boolean isGranted;
    public CreditCard(String clientName, String issuerBank, String bankAmount, int card_id,int balanceAmount, int 
    cvc_Number, double interestRate, String expirationDate)
    {
        super(clientName,issuerBank,bankAmount,card_id,balanceAmount);
        super.setClientName(clientName);
        this.cvc_Number=cvc_Number;
        this.interestRate=interestRate;
        this.expirationDate=expirationDate;
        this.isGranted=false;
    }
    //accessor methods to get cvc_Number,credit_Limit,expirationDate,gracePeriod and isGranted
    public int getCvc_Number()
    {
        return this.cvc_Number;
    }
    public double getCredit_Limit()
    {
        return this.credit_Limit;
    }
    public String getExpirationDate()
    {
        return this.expirationDate;
    }
    public int getGracePeriod()
    {
        return this.gracePeriod;
    }
    public double getInterestRate()
    {
        return this.interestRate;
    }
    public boolean getIsGranted()
    {
        return this.isGranted;
    }
    //Set credit limit to method
    public void setCredit_Limit(double newCredit_Limit,int newGracePeriod)
    {
        if(newCredit_Limit<=2.5*super.getbalanceAmount())
        {
           this.gracePeriod=newGracePeriod;
           this.credit_Limit=newCredit_Limit;
           this.isGranted=true;
        }
        else
        {
            System.out.println("Credit cannot be issued");
        }
    }
    //cancle credit card to method
    public void cancleCreditCard()
    {
            this.cvc_Number=0;
            this.credit_Limit=0;
            this.gracePeriod=0;
            this.isGranted=false;
    }
    //display details to method of credit card
    public void display()
    {
        System.out.println("Cvc_Number is:"+this.cvc_Number);
        System.out.println("Interest rate is:"+this.interestRate);
        System.out.println("Expiration date is:"+this.expirationDate);
        if(isGranted)
        {
            super.display();
            System.out.println("credit_Limit:"+this.credit_Limit);
            System.out.println("Grace period:"+this.gracePeriod);
        }
        else{
            System.out.println("There is no existance of card");
        }
    }
}


