import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
/**
 * Write a description of class BankGUI here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class BankGUI implements ActionListener 
{
    //Declaring attributes of JPanel, JFrame, ArrayList, JTextField, JButton, JLabel, JComboBox
 private ArrayList < BankCard > CardFile;
 private JFrame frame;
 private JPanel pan1, pan2 , pan3, pan4, pan5, pan6;
 private JTextField textfCilentNameC,textfIssuerBankC,textfBankAccountC,textfCardIDC,textfBalanceAmountC,textfCvcNumberC,textfInterestRateC,textfCardIDW,textfWithdrawalAmount,textfPinNumberW,textfCilentNameD,textfIssuerBankD,textfBankAccountD,textfCardIDD,textfBalanceAmountD,textfPinNumberD,textfCardIDCl,textfCreditLimitCl,textfGracePeriod,textfCardIDCc;
 private JButton jbutCredit,jbutDebit,jbutSubmitC,jbutClearC,jbutDisplayC,jbutCreditLimit,jbutCancleCredit,jbutSubmitW,jbutClearW,jbutBackW,jbutSubmitD,jbutClearD,jbutWithdrawalD,jbutDisplayD,jbutBackC,jbutBackD,jbutSubmitCl,jbutClearCl,jbutBackCl,jbutSubmitCc,jbutClearCc,jbutBackCc;
 private JLabel labBank,labCreditCard,labClientNameC,labIssuerBankC,labBankAccountC,labCardIDC,labBalanceAmountC,labCvcNumberC,labInterestRateC,labExpirationDateC,labWithdrawal,labCardIDW,labWithdrawalAmount,labWithdrawalDate,labPinNumberW,labDebitCard,labCilentNameD,labIssuerBankD,labBankAccountD,labCardIDD,labBalanceAmountD,labPinNumberD,labCreditLimit,labCardIDCl,labCreditLimitCl,labGracePeriod,labCancleCredit,labCardIDCc;
 private JComboBox<String> cobowithdrawal1, cobowithdrawal2,cobowithdrawal3,coboexpiration4,coboexpiration5,coboexpiration6;
    public BankGUI() 
    {
       JFrame frame = new JFrame("Form");
       CardFile= new ArrayList<BankCard>();
       //set color to panel
       pan1 = new JPanel();
       pan1.setBackground(Color.orange);
       pan2 = new JPanel();
       pan2.setBackground(Color.orange);
       pan3 = new JPanel();
       pan3.setBackground(Color.orange);
       pan4 = new JPanel();
       pan4.setBackground(Color.orange);
       pan5 = new JPanel();
       pan5.setBackground(Color.orange);
       pan6 = new JPanel();
       pan6.setBackground(Color.orange);
       
       pan1.setLayout(null);
       pan2.setLayout(null);
       pan3.setLayout(null);
       pan4.setLayout(null);
       pan5.setLayout(null);
       pan6.setLayout(null);
       //initializing the Textfield
       textfCilentNameC = new JTextField();
       textfIssuerBankC = new JTextField();
       textfBankAccountC = new JTextField();
       textfCardIDC = new JTextField();
       textfBalanceAmountC = new JTextField();
       textfCvcNumberC = new JTextField();
       textfInterestRateC = new JTextField();
       
       textfCardIDW = new JTextField();
       textfWithdrawalAmount = new JTextField();
       textfPinNumberW = new JTextField();
       
       textfCilentNameD = new JTextField();
       textfIssuerBankD = new JTextField();
       textfBankAccountD = new JTextField();
       textfCardIDD = new JTextField();
       textfBalanceAmountD = new JTextField();
       textfPinNumberD = new JTextField();
       
       textfCardIDCl = new JTextField();
       textfCreditLimitCl = new JTextField();
       textfGracePeriod = new JTextField();
       
       textfCardIDCc = new JTextField();
       
       //inatializing the JLabel
       labBank = new JLabel("Bank Form");
       
       labCreditCard = new JLabel("Credit Card");
       labClientNameC = new JLabel("Client Name:");
       labIssuerBankC = new JLabel("Issuer Bank:");
       labBankAccountC = new JLabel("Bank Account:");
       labCardIDC = new JLabel("CardID:");
       labBalanceAmountC = new JLabel("Balance Amount:");
       labCvcNumberC = new JLabel("CVC Number:");
       labInterestRateC = new JLabel("Interest Rate:");
       labExpirationDateC = new JLabel("Expiration Date:");
       
       labWithdrawal = new JLabel("Withdrawal Card");
       labCardIDW = new JLabel("CardID:");
       labWithdrawalAmount = new JLabel("Withdrawal Amount:");
       labWithdrawalDate = new JLabel("Withdrawal Date:");
       labPinNumberW = new JLabel("PIN Number:");
       
       labDebitCard = new JLabel("Debit Card");
       labCilentNameD = new JLabel("Cilent Name:");
       labIssuerBankD = new JLabel("Issuer Bank:");
       labBankAccountD = new JLabel("Bank Account:");
       labCardIDD = new JLabel("CardID:");
       labBalanceAmountD = new JLabel("Balance Amount:");
       labPinNumberD = new JLabel("PIN Number:");
       
       labCreditLimit = new JLabel("Credit Limit");
       labCardIDCl = new JLabel("CardID:");
       labCreditLimitCl = new JLabel("Credit Limit:");
       labGracePeriod = new JLabel("Grace Period:");
       
       labCancleCredit = new JLabel("Cancel Credit");
       labCardIDCc = new JLabel("CardID:");
       //initalizing the JButtons
       jbutCredit = new JButton("Credit");
       jbutDebit = new JButton("Debit");
       
       jbutSubmitC = new JButton("Submit");
       jbutClearC = new JButton("Clear");
       jbutDisplayC = new JButton("Display");
       jbutCreditLimit = new JButton("Credit Limit");
       jbutCancleCredit = new JButton("Cancle Credit");
       jbutBackC = new JButton("Back");
       
       jbutSubmitW = new JButton("Submit");
       jbutClearW = new JButton("Clear");
       jbutBackW = new JButton("Back");
       
       jbutSubmitD = new JButton("Submit");
       jbutClearD = new JButton("Clear");
       jbutWithdrawalD = new JButton("Withdrawal");
       jbutDisplayD = new JButton("Display");
       jbutBackD = new JButton("Back");
       
       jbutSubmitCl = new JButton("Submit");
       jbutClearCl = new JButton("Clear");
       jbutBackCl = new JButton("Back");
       
       jbutSubmitCc = new JButton("Submit");
       jbutClearCc = new JButton("Clear");
       jbutBackCc = new JButton("Back");
       //initalizing the JComboBox
       String[] Year = {"2014","2015","2016","2017","2018","2019","2020","2021","2022","2023"};
       cobowithdrawal1 = new JComboBox<>(Year);
       coboexpiration4 = new JComboBox<>(Year);
       String[] Month = {"January","February","March","April","May","June","July","August","September","October","November","December"};
       cobowithdrawal2 = new JComboBox<>(Month);
       coboexpiration5 = new JComboBox<>(Month);
       String[] Day = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
       cobowithdrawal3 = new JComboBox<>(Day);
       coboexpiration6 = new JComboBox<>(Day);
       JComboBox cobowithdrawal1 = new JComboBox<>(Year);
       JComboBox cobowithdrawal2 = new JComboBox<>(Month);
       JComboBox cobowithdrawal3 = new JComboBox<>(Day);
       JComboBox coboexpiration4 = new JComboBox<>(Year); 
       JComboBox coboexpiration5 = new JComboBox<>(Month); 
       JComboBox coboexpiration6 = new JComboBox<>(Day); 
       //setting the location of JLable
       labBank.setBounds(291, 44, 123, 36);
       
       labCreditCard.setBounds(286, 44, 133, 36);
       labClientNameC.setBounds(21, 158, 85, 22);
       labIssuerBankC.setBounds(353, 158, 82, 22);
       labBankAccountC.setBounds(21, 255, 93, 22);
       labCardIDC.setBounds(350, 255, 66, 22);
       labBalanceAmountC.setBounds(21, 352, 110, 22);
       labCvcNumberC.setBounds(353, 352, 91, 22);
       labInterestRateC.setBounds(21, 449, 88, 22);
       labExpirationDateC.setBounds(355, 449, 104, 22);
       
       labWithdrawal.setBounds(257, 47, 192, 36);
       labCardIDW.setBounds(154, 145, 56, 24);
       labWithdrawalAmount.setBounds(91, 250, 125, 24);
       labWithdrawalDate.setBounds(100, 367, 107, 24);
       labPinNumberW.setBounds(130, 484, 89, 24);
       
       labDebitCard .setBounds(289, 45, 128, 36);
       labCilentNameD.setBounds(46, 145, 89, 22);
       labIssuerBankD.setBounds(360, 145, 86, 22);
       labBankAccountD.setBounds(46, 282, 85, 22);
       labCardIDD.setBounds(368, 282, 56, 22);
       labBalanceAmountD.setBounds(46, 417, 116, 22);
       labPinNumberD.setBounds(353, 417, 98, 22);
       
       labCreditLimit.setBounds(287, 64, 131, 36);
       labCardIDCl.setBounds(191, 151, 53, 24);
       labCreditLimitCl.setBounds(165, 288, 79, 24);
       labGracePeriod.setBounds(148, 425, 96, 24);
       
       labCancleCredit.setBounds(269, 81, 168, 45);
       labCardIDCc.setBounds(210, 273, 52, 28);
       //setting the location of Textfield 
       textfCilentNameC.setBounds(147, 158, 170, 22);
       textfIssuerBankC.setBounds(464, 158, 201, 22);
       textfBankAccountC.setBounds(147, 255, 170, 22);
       textfCardIDC.setBounds(470, 253, 201, 22);
       textfBalanceAmountC.setBounds(147, 352, 170, 22);
       textfCvcNumberC.setBounds(470, 352, 201, 22);
       textfInterestRateC.setBounds(147, 449, 170, 22);
       
       textfCardIDW.setBounds(247, 145, 240, 24);
       textfWithdrawalAmount.setBounds(247, 256, 251, 24);
       textfPinNumberW.setBounds(247, 478, 251, 24);
       
       textfCilentNameD.setBounds(162, 145, 185, 22);
       textfIssuerBankD.setBounds(459, 147, 217, 22);
       textfBankAccountD.setBounds(162, 282, 185, 22);
       textfCardIDD.setBounds(457, 282, 214, 22);
       textfBalanceAmountD.setBounds(162, 417, 185, 22);
       textfPinNumberD.setBounds(457, 417, 214, 22);
       
       textfCardIDCl.setBounds(287, 151, 219, 24);
       textfCreditLimitCl.setBounds(287, 288, 219, 24);
       textfGracePeriod.setBounds(287, 425, 219, 24);
       
       textfCardIDCc.setBounds(296, 273, 271, 28);
       //setting the location of JButton
       jbutCredit.setBounds(87, 306, 135, 45);
       jbutDebit.setBounds(448, 306, 135, 45);
       
       jbutSubmitC.setBounds(27, 512, 89, 32);
       jbutClearC.setBounds(144, 512, 64, 32);
       jbutDisplayC.setBounds(266, 512, 94, 32);
       jbutCreditLimit.setBounds(388, 512, 108, 32);
       jbutCancleCredit.setBounds(519, 512, 118, 32);
       jbutBackC.setBounds(491, 45, 120, 32);
       
       jbutSubmitW.setBounds(57, 565, 87, 36);
       jbutClearW.setBounds(296, 565, 95, 36);
       jbutBackW.setBounds(543, 565, 85, 36);
       
       jbutSubmitD .setBounds(46, 567, 120, 32);
       jbutClearD.setBounds(203, 567, 120, 32);
       jbutWithdrawalD.setBounds(347, 567, 140, 32);
       jbutDisplayD.setBounds(520, 565, 120, 32);
       jbutBackD.setBounds(533, 45, 120, 32);
       
       jbutSubmitCl.setBounds(61, 562, 120, 32);
       jbutClearCl.setBounds(239, 562, 120, 32);
       jbutBackCl.setBounds(417, 562, 120, 32);
       
       jbutSubmitCc.setBounds(79, 500, 120, 36);
       jbutClearCc.setBounds(247, 500, 120, 36);
       jbutBackCc.setBounds(469, 500, 120, 36);
       //setting the location of JComboBox
       cobowithdrawal1.setBounds(247, 367, 80, 24);
       cobowithdrawal2.setBounds(343, 367, 78, 24);
       cobowithdrawal3.setBounds(439, 367, 55, 24);
       coboexpiration4.setBounds(470, 449, 65, 22);
       coboexpiration5.setBounds(546, 449, 73, 22);
       coboexpiration6.setBounds(630, 449, 65, 22);
       //adding the panel to the frame
       frame.add(pan6);
       frame.add(pan5);        
       frame.add(pan4);
       frame.add(pan3);
       frame.add(pan2);
       frame.add(pan1);
       //adding the Jlable component to panel
       pan1.add(labBank);
       
       pan2.add(labCreditCard);
       pan2.add(labClientNameC);
       pan2.add(labIssuerBankC);
       pan2.add(labBankAccountC);
       pan2.add(labCardIDC);
       pan2.add(labBalanceAmountC);
       pan2.add(labCvcNumberC);
       pan2.add(labInterestRateC);
       pan2.add(labExpirationDateC);
       
       pan3.add(labWithdrawal);
       pan3.add(labCardIDW);
       pan3.add(labWithdrawalAmount);
       pan3.add(labWithdrawalDate);
       pan3.add(labPinNumberW);
       
       pan4.add(labDebitCard );
       pan4.add(labCilentNameD);
       pan4.add(labIssuerBankD);
       pan4.add(labBankAccountD);
       pan4.add(labCardIDD);
       pan4.add(labBalanceAmountD);
       pan4.add(labPinNumberD);
       
       pan5.add(labCreditLimit);
       pan5.add(labCardIDCl);
       pan5.add(labCreditLimitCl);
       pan5.add(labGracePeriod);
       
       pan6.add(labCancleCredit);
       pan6.add(labCardIDCc);
       // adding the Textfield to the panel
       pan2.add(textfCilentNameC);
       pan2.add(textfIssuerBankC);
       pan2.add(textfBankAccountC);
       pan2.add(textfCardIDC);
       pan2.add(textfBalanceAmountC);
       pan2.add(textfCvcNumberC);
       pan2.add(textfInterestRateC);
       
       pan3.add(textfCardIDW);
       pan3.add(textfWithdrawalAmount);
       pan3.add(textfPinNumberW);
       
       pan4.add(textfCilentNameD);
       pan4.add(textfIssuerBankD);
       pan4.add(textfBankAccountD);
       pan4.add(textfCardIDD);
       pan4.add(textfBalanceAmountD);
       pan4.add(textfPinNumberD);
       
       pan5.add(textfCardIDCl);
       pan5.add(textfCreditLimitCl);
       pan5.add(textfGracePeriod);
       
       pan6.add(textfCardIDCc);
       //adding the JButton to the panel
       pan1.add(jbutCredit);
       pan1.add(jbutDebit);
       
       pan2.add(jbutSubmitC);
       pan2.add(jbutClearC);
       pan2.add(jbutDisplayC);
       pan2.add(jbutCreditLimit);
       pan2.add(jbutCancleCredit);
       pan2.add(jbutBackC);
       
       pan3.add(jbutSubmitW);
       pan3.add(jbutClearW);
       pan3.add(jbutBackW);
       
       pan4.add(jbutSubmitD);
       pan4.add(jbutClearD);
       pan4.add(jbutWithdrawalD);
       pan4.add(jbutDisplayD);
       pan4.add(jbutBackD);
       
       pan5.add(jbutSubmitCl);
       pan5.add(jbutClearCl);
       pan5.add(jbutBackCl);
       
       pan6.add(jbutSubmitCc);
       pan6.add(jbutClearCc);
       pan6.add(jbutBackCc);
       //adding the JComboBox to the panel
       pan3.add(cobowithdrawal1);
       pan3.add(cobowithdrawal2);
       pan3.add(cobowithdrawal3);
       
       pan2.add(coboexpiration4);
       pan2.add(coboexpiration5);
       pan2.add(coboexpiration6);
       
       jbutCredit.addActionListener(this);
       jbutDebit.addActionListener(this);
       jbutSubmitC.addActionListener(this);
       jbutClearC.addActionListener(this);
       jbutDisplayC.addActionListener(this);
       jbutCreditLimit.addActionListener(this);
       jbutCancleCredit.addActionListener(this);
       jbutSubmitW.addActionListener(this);
       jbutClearW.addActionListener(this);
       jbutBackW.addActionListener(this);
       jbutSubmitD .addActionListener(this);
       jbutClearD.addActionListener(this);
       jbutWithdrawalD.addActionListener(this);
       jbutDisplayD.addActionListener(this);
       jbutBackC.addActionListener(this);
       jbutBackD.addActionListener(this);
       jbutSubmitCl.addActionListener(this);
       jbutClearCl.addActionListener(this);
       jbutBackCl.addActionListener(this);
       jbutSubmitCc.addActionListener(this);
       jbutClearCc.addActionListener(this);
       jbutBackCc.addActionListener(this);
       
       frame.setVisible(true);
       frame.setSize(705,675);
       frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
 }
    public void actionPerformed(ActionEvent abc){
        //CreditCard JButton Submit
       if(abc.getSource() == jbutSubmitC)
        {
          if(textfCilentNameC.getText().isEmpty()||textfIssuerBankC.getText().isEmpty()||textfBankAccountC.getText().isEmpty()||textfCardIDC.getText().isEmpty()||textfBalanceAmountC.getText().isEmpty()||textfCvcNumberC.getText().isEmpty()||textfInterestRateC.getText().isEmpty()){
              JOptionPane.showMessageDialog(frame,"The form is not filled","Invalid",JOptionPane.INFORMATION_MESSAGE);
        }
       else{
           try{
            String clientName = textfCilentNameC.getText();
            String issuerBank = textfIssuerBankC.getText();
            String bankAmount = textfBankAccountC.getText();
            int card_id = Integer.parseInt(textfCardIDC.getText());
            int balanceAmount = Integer.parseInt(textfBalanceAmountC.getText());
            int cvc_Number = Integer.parseInt(textfCvcNumberC.getText());
            double interestRate = Double.parseDouble(textfInterestRateC.getText());
            String expirationDate = coboexpiration4.getSelectedItem().toString()+ coboexpiration5.getSelectedItem().toString()+coboexpiration6.getSelectedItem().toString();
            BankCard bankc = new CreditCard(clientName,issuerBank,bankAmount,card_id,balanceAmount,cvc_Number,interestRate,expirationDate);
            CardFile.add(bankc);
            JOptionPane.showMessageDialog(frame,"The form is filled","Sucessful",JOptionPane.INFORMATION_MESSAGE);
        }
        catch(NumberFormatException a){
            JOptionPane.showMessageDialog(frame,"The form is not filled","Invalid",JOptionPane.INFORMATION_MESSAGE);
        }
      }
     }
     //DebitCard JButton Submit
    if(abc.getSource() == jbutSubmitD)
        {
         if(textfCilentNameD.getText().isEmpty()||textfIssuerBankD.getText().isEmpty()||textfBankAccountD.getText().isEmpty()||textfCardIDD.getText().isEmpty()||textfBalanceAmountD.getText().isEmpty()||textfPinNumberD.getText().isEmpty()){
             JOptionPane.showMessageDialog(frame,"The form is not filled","Invalid",JOptionPane.INFORMATION_MESSAGE);
          }
         else{
             try{
            String clientName = textfCilentNameD.getText();
            String issuerBank = textfIssuerBankD.getText();
            String bankAccount = textfBankAccountD.getText();
            int card_id = Integer.parseInt(textfCardIDD.getText());
            int balanceAmount = Integer.parseInt(textfBalanceAmountD.getText());
            int pin_Number = Integer.parseInt(textfPinNumberD.getText());
            BankCard bankd = new DebitCard(clientName,issuerBank,bankAccount,card_id,balanceAmount,pin_Number);
            CardFile.add(bankd);
            JOptionPane.showMessageDialog(frame,"The form is filled","Sucessful",JOptionPane.INFORMATION_MESSAGE);
         }
         catch(NumberFormatException a){
            JOptionPane.showMessageDialog(frame,"The form is not filled","Invalid",JOptionPane.INFORMATION_MESSAGE);
        }
        }
        }
        //Withdraw for debit JButton Submit
        if(abc.getSource() == jbutSubmitW)
    {
           if(textfCardIDW.getText().isEmpty()||textfWithdrawalAmount.getText().isEmpty()||textfPinNumberW.getText().isEmpty()){
               JOptionPane.showMessageDialog(frame,"The form is not filled","Invalid",JOptionPane.INFORMATION_MESSAGE);
           }
           else{
               for(BankCard bankdw:CardFile){
                   if(bankdw instanceof DebitCard){
                       if(textfCardIDD.getText().equals(textfCardIDW.getText())){
                           try{
                           int withdrawalAmount = Integer.parseInt(textfWithdrawalAmount.getText());
                           String dateofWithdrawal = cobowithdrawal1.getSelectedItem().toString()+cobowithdrawal2.getSelectedItem().toString()+cobowithdrawal3.getSelectedItem().toString();
                           int pin_number = Integer.parseInt(textfPinNumberW.getText());
                           ((DebitCard)bankdw).withdraw(withdrawalAmount,dateofWithdrawal,pin_number);
                           JOptionPane.showMessageDialog(frame,"The form is filled","Sucessful",JOptionPane.INFORMATION_MESSAGE);
                       }
                       catch(NumberFormatException c){
                           JOptionPane.showMessageDialog(frame,"The form is not filled","Invalid",JOptionPane.INFORMATION_MESSAGE);
                       }
                    }
                       else{
                           JOptionPane.showMessageDialog(frame,"The form content is wrong","Invalid",JOptionPane.INFORMATION_MESSAGE);
                       }
                   }
               }
           }
       }
       //CreditCard for the credit limit JButton Submit
             if(abc.getSource() == jbutSubmitCl)
       {
           if(textfCardIDCl.getText().isEmpty()||textfCreditLimitCl.getText().isEmpty()||textfGracePeriod.getText().isEmpty()){
               JOptionPane.showMessageDialog(frame,"The form is not filled","Invalid",JOptionPane.INFORMATION_MESSAGE);
           }
           else{
                try{
               for(BankCard bankcl:CardFile){
                   if(bankcl instanceof CreditCard){
                   if(Integer.parseInt(textfCardIDC.getText())==(Integer.parseInt(textfCardIDCl.getText()))){
                       
                       double credit_Limit = Double.parseDouble(textfCreditLimitCl.getText()); 
                       int gracePeriod = Integer.parseInt(textfGracePeriod.getText());
                       ((CreditCard)bankcl).setCredit_Limit(credit_Limit,gracePeriod);
                       JOptionPane.showMessageDialog(frame,"The form is filled","Sucessful",JOptionPane.INFORMATION_MESSAGE);
                    }
                   }
                   else{
                       JOptionPane.showMessageDialog(frame,"card id is wrong","Invalid",JOptionPane.INFORMATION_MESSAGE);
                   }
                  }
               }
               catch(NumberFormatException hh){
                        JOptionPane.showMessageDialog(frame,"check again","Sucessful",JOptionPane.INFORMATION_MESSAGE);
                    }
           }
        }
        //CreditCard for the card id JButton Submit
       if(abc.getSource() == jbutSubmitCc)
       {
           if(textfCardIDCc.getText().isEmpty()){
               JOptionPane.showMessageDialog(frame,"The form is not filled","Invalid",JOptionPane.INFORMATION_MESSAGE);
            }
            else{
                for(BankCard bankcc:CardFile){
                    if(bankcc instanceof CreditCard){
                        if(textfCardIDC.getText().equals( textfCardIDCc.getText())){
                            ((CreditCard)bankcc).cancleCreditCard();
                            JOptionPane.showMessageDialog(frame,"The form is filled","Sucessful",JOptionPane.INFORMATION_MESSAGE);
                        }
                        else{
                            JOptionPane.showMessageDialog(frame,"The cardID is wrong","Invalid",JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                }
            }
           }
           //Display method for the CreditCard
       if(abc.getSource() == jbutDisplayC){
           for(BankCard bankdc:CardFile){
              if(bankdc instanceof CreditCard){ 
                  bankdc.display();
                  JOptionPane.showMessageDialog(frame,"The Credit is display","Right",JOptionPane.INFORMATION_MESSAGE);
         }
        }
      }
      //Display method for DebitCard
       if(abc.getSource() == jbutDisplayD){
           for(BankCard bankdd:CardFile){
               if(bankdd instanceof DebitCard){
                   bankdd.display();
                   JOptionPane.showMessageDialog(frame,"The Debit is display","Right",JOptionPane.INFORMATION_MESSAGE);
               }
           }
       }
       
      if(abc.getSource() == jbutCredit){
           pan1.setVisible(false);
           pan2.setVisible(true);
           pan2.setSize(705,675);
      }
      else if(abc.getSource() == jbutDebit){
           pan1.setVisible(false);
           pan4.setVisible(true);
           pan4.setSize(705,675);
      }
      else if(abc.getSource() == jbutCreditLimit){
          pan2.setVisible(false);
          pan5.setVisible(true);
          pan5.setSize(705,675);
      }
      else if(abc.getSource() == jbutCancleCredit){
          pan2.setVisible(false);
          pan6.setVisible(true);
          pan6.setSize(705,675);
      }
      else if(abc.getSource() == jbutWithdrawalD){
          pan4.setVisible(false);
          pan3.setVisible(true);
          pan3.setSize(705,675);
      }
      else if(abc.getSource() == jbutBackW){
          pan4.setVisible(true);
          pan3.setVisible(false);
          pan3.setSize(705,675);
      }
      else if (abc.getSource() == jbutBackC){
          pan1.setVisible(true);
          pan2.setVisible(false);
          pan2.setSize(705,675);
      }
      else if (abc.getSource() == jbutBackD){
          pan1.setVisible(true);
          pan4.setVisible(false);
          pan4.setSize(705,675);
      }
      else if(abc.getSource() == jbutBackCl){
          pan2.setVisible(true);
          pan5.setVisible(false);
          pan5.setSize(705,675);
      }
      else if(abc.getSource() == jbutBackCc){
          pan2.setVisible(true);
          pan6.setVisible(false);
          pan6.setSize(705,675);
      }
      else if(abc.getSource() == jbutClearC){
            textfCilentNameC.setText("");
            textfIssuerBankC.setText(""); 
            textfBankAccountC.setText("");
            textfCardIDC.setText("");
            textfBalanceAmountC.setText("");
            textfCvcNumberC.setText("");
            textfInterestRateC.setText("");
      }
       else if(abc.getSource() == jbutClearW){
            textfCardIDW.setText("");
            textfWithdrawalAmount.setText("");
            textfPinNumberW.setText("");
      }
      else if(abc.getSource() == jbutClearD){
            textfCilentNameD.setText("");
            textfIssuerBankD.setText("");
            textfBankAccountD.setText("");
            textfCardIDD.setText("");
            textfBalanceAmountD.setText("");
            textfPinNumberD.setText("");
      }
      else if(abc.getSource() == jbutClearCl){
          textfCardIDCl.setText("");
          textfCreditLimitCl.setText("");
          textfGracePeriod.setText("");
      }
      else if(abc.getSource() == jbutClearCc){
          textfCardIDCc.setText("");
      }
 }
 public static void main (String[]args){
    BankGUI bankobj = new BankGUI();
}
    }






