
/**
 * Write a description of class DebitCard here.
 *
 * @author (22067339  Trisana Gurung)
 * @version (1.0.0)
 */
public class DebitCard extends BankCard
{
    //Declaring attribute such as pin_number,withdrawalAmount,dateofwithdrawal,haswithdrawal.
    private int pin_Number;
    private int withdrawalAmount;
    private String dateofWithdrawal;
    private boolean haswithdrawan;
    public DebitCard(String clientName, String issuerBank, String bankAccount, int card_id, int balanceAmount,int pin_Number)
    {
        super(clientName, issuerBank, bankAccount, card_id, balanceAmount);
        super.setClientName(clientName);
        this.pin_Number = pin_Number;
        this.withdrawalAmount = withdrawalAmount;
        this.haswithdrawan = false;
    }
    //accessor methods to get pin_Number,withdrawalAmount,dateofwithdrawal and haswithdrawal
    public int getpin_Number()
    {
        return this.pin_Number;
    }
    public double getwithdrawalAmount() 
    {
        return this.withdrawalAmount;
    }
    //setter methods to set withdrawalAmount
    public void setWithdrawalAmount(int withdrawalAmount)
    {
        this.withdrawalAmount = withdrawalAmount;
    }
    public String getDateOfWithdrawal()
    {
        return this.dateofWithdrawal;
    }
    public boolean gethasWithdrawn()
    {
        return this.haswithdrawan;
    }
    //set withdraw to method.
    public void withdraw(int withdrawalAmount,String dateofWithdrawal,int pin_number)
    {
        if(pin_number==this.pin_Number)
        {
            if(withdrawalAmount<=this.getbalanceAmount())
            {
                this.withdrawalAmount=withdrawalAmount;
                this.dateofWithdrawal=dateofWithdrawal;
                this.haswithdrawan=true;
                this.setBalanceAmount(this.getbalanceAmount()- withdrawalAmount);
            }
            else
            {
                System.out.println("Balance insufficient amount");
            }
        }
        else
        {
            System.out.println("Pin_number Invalid");
        }
    }
    //dispaly methods of the attributes.
    public void display()
    {
        super.display();
        if(haswithdrawan== true)
        {
             System.out.println("pib number:" + this.pin_Number);
            System.out.println("Withdrawal amount is:"+this.withdrawalAmount);
            System.out.println("Date of withdrawal is:"+this.dateofWithdrawal);
        }
        else
        {
            System.out.println("Transaction has been not carried out yet");
        }
    }
}

